#include "patrols_loader.hpp"
#include "eos/configuration/models.pb.h"
#include "tinyxml.h"

namespace eos
{
  namespace eosconfig
  {
    namespace tag
    {
      const char PATROLS[] = "patrols";
      const char PATROL[] = "patrol";
      const char NAME[] = "name";
      const char TYPE[] = "type";
      const char POINTS[] = "points";
      const char POINT[] = "point";
      const char X[] = "x";
      const char Y[] = "y";
      const char IMPORTANCE[] = "importance";
      const char ACTIVE[] = "active";
    }

    void read_points(TiXmlNode *xml, Patrol &patrol)
    {
      TiXmlNode *point = xml->FirstChildElement(tag::POINT);
      while (point)
      {
        Patrol::Point *p = patrol.mutable_points()->Add();
        p->mutable_position()->set_x(xmlhelpers::read_int(point, tag::X));
        p->mutable_position()->set_y(xmlhelpers::read_int(point, tag::Y));
        p->set_priority(xmlhelpers::read_type<Patrol::Priority>(point, tag::IMPORTANCE));
        point = point->NextSibling();
      }
    }

    void write_points(TiXmlNode *xml, Patrol const &patrol)
    {
      for (auto it = patrol.points().begin(); it != patrol.points().end(); ++it)
      {
        Patrol::Point point = *it;

        TiXmlElement *point_xml = new TiXmlElement(tag::POINT);

        xmlhelpers::dump(point_xml, tag::X, point.position().x());
        xmlhelpers::dump(point_xml, tag::Y, point.position().y());
        xmlhelpers::dump(point_xml, tag::IMPORTANCE, point.priority());

        xml->LinkEndChild(point_xml);
      }
    }

    TiXmlNode *operator>>(TiXmlNode *xml, Patrol &patrol)
    {
      patrol.set_name(xmlhelpers::read(xml, tag::NAME));
      patrol.set_type(xmlhelpers::read_type<Patrol::Type>(xml, tag::TYPE));
      read_points(xml->FirstChildElement(tag::POINTS), patrol);
      return xml;
    }

    TiXmlNode *operator<<(TiXmlNode *xml, Patrol const &patrol)
    {
      xmlhelpers::dump(xml, tag::NAME, patrol.name());
      xmlhelpers::dump(xml, tag::TYPE, patrol.type());

      TiXmlElement *points = new TiXmlElement(tag::POINTS);

      write_points(points, patrol);

      xml->LinkEndChild(points);
      return xml;
    }

    BaseResource::Ptr PatrolsLoader::load(const RawData &data) const
    {
      TiXmlDocument doc;
      doc.Parse(data.c_str(), 0, TIXML_DEFAULT_ENCODING);

      auto patrols = rsc::alloc<Patrols>();

      patrols->set_timestamp(xmlhelpers::read_timestamp(doc.RootElement()));

      TiXmlNode *xml_patrols = doc.FirstChildElement(tag::PATROLS);
      if (xml_patrols)
      {
        TiXmlNode *xml_patrol = xml_patrols->FirstChildElement(tag::PATROL);
        while (xml_patrol)
        {
          Patrol *patrol = patrols->add_patrols();
          xml_patrol >> *patrol;
          xml_patrol = xml_patrol->NextSibling();
        }
      }
      return patrols;
    }

    bool PatrolsLoader::save(RawData &data, BaseResource::Ptr const &rsc) const
    {
      TiXmlDocument doc;
      TiXmlElement *root = xmlhelpers::createDocument(tag::PATROLS, doc);

      auto patrols = rsc::as<Patrols>(rsc);

      xmlhelpers::dump_timestamp(root, patrols->timestamp());

      for (auto const &patrol : patrols->patrols())
      {
        TiXmlElement *xml_patrol = new TiXmlElement(tag::PATROL);
        xml_patrol << patrol;
        root->LinkEndChild(xml_patrol);
      }

      return xmlhelpers::dump(doc, data);
    }
  }
}
