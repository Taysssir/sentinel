#include "eos/configuration/models.pb.h"
#include "users_loader.hpp"

namespace eos
{
  namespace eosconfig
  {
    namespace tag
    {
      const char USERS[] = "users";
      const char USER[] = "user";
      const char LOGIN[] = "login";
      const char PASSWORD[] = "password";
      const char TYPE[] = "type";
      const char LAYOUT[] = "layout";
      const char LAYOUT_TYPE[] = "layout_type";
      const char LAYOUT_SPLIT_TYPE[] = "split_type";
      const char LAYOUT_SIZE[] = "layout_size";
    }

    TiXmlNode *operator>>(TiXmlNode *xml, User::Layout &layout)
    {
      layout.set_type(xmlhelpers::read(xml, tag::LAYOUT_TYPE));
      layout.set_orientation(xmlhelpers::read_type<User::Layout::Orientation>(xml, tag::LAYOUT_SPLIT_TYPE));
      layout.set_size(xmlhelpers::read_float(xml, tag::LAYOUT_SIZE));

      TiXmlNode *layout_xml = xml->FirstChildElement(tag::LAYOUT);

      //User::Layout::Layouts layouts;
      while (layout_xml)
      {
        User::Layout *sub_layout = layout.mutable_children()->Add();
        //User::Layout layout;
        layout_xml >> *sub_layout;
        //layouts.push_back(layout);
        layout_xml = layout_xml->NextSibling();
      }
      //layout.set_layouts(layouts);

      return xml;
    }

    TiXmlNode *operator>>(TiXmlNode *xml, User &user)
    {
      user.set_login(xmlhelpers::read(xml, tag::LOGIN));
      user.set_password(xmlhelpers::read(xml, tag::PASSWORD));
      user.set_type(xmlhelpers::read_type<User::Type>(xml, tag::TYPE));
      TiXmlNode *layout_xml = xml->FirstChildElement(tag::LAYOUT);
      if (layout_xml)
      {
        //User::Layout layout;
        User::Layout *layout = user.mutable_layout()->add_children();
        layout_xml >> *layout;
        //user.set_layout(layout);
      }
      return xml;
    }

    BaseResource::Ptr UsersLoader::load(RawData const &data) const
    {
      TiXmlDocument doc;
      doc.Parse(data.c_str(), 0, TIXML_DEFAULT_ENCODING);
      Resource<Users>::Ptr ptr = Resource<Users>::alloc();
      TiXmlNode *users_xml = doc.FirstChildElement(tag::USERS);
      if (users_xml)
      {
        TiXmlNode *user_xml = users_xml->FirstChildElement(tag::USER);
        while (user_xml)
        {
          //User user;
          User *user = ptr->mutable_users()->Add();
          user_xml >> *user;
          //ptr->push_back(user);
          user_xml = user_xml->NextSibling();
        }
      }
      return ptr;
    }

    TiXmlNode *operator<<(TiXmlNode *xml, User::Layout const &layout)
    {
      TiXmlElement *layout_xml = new TiXmlElement(tag::LAYOUT);
      xml->LinkEndChild(layout_xml);

      xmlhelpers::dump(layout_xml, tag::LAYOUT_TYPE, layout.type());
      xmlhelpers::dump(layout_xml, tag::LAYOUT_SPLIT_TYPE, layout.orientation());
      xmlhelpers::dump(layout_xml, tag::LAYOUT_SIZE, layout.size());

      if (layout.children().size() == 2)
      {
        layout_xml << layout.children().Get(0);
        layout_xml << layout.children().Get(1);
      }

      return xml;
    }

    TiXmlNode *operator<<(TiXmlNode *xml, User const &user)
    {
      xmlhelpers::dump(xml, tag::LOGIN, user.login());
      xmlhelpers::dump(xml, tag::PASSWORD, user.password());
      xmlhelpers::dump(xml, tag::TYPE, user.type());
      xml << user.layout();
      return xml;
    }

    bool UsersLoader::save(RawData &data, BaseResource::Ptr const &rsc) const
    {
      TiXmlDocument doc;
      TiXmlElement *root = xmlhelpers::createDocument(tag::USERS, doc);

      auto users = rsc::as<Users>(rsc);

      for (auto const &user : users->users())
      {
        TiXmlElement *xml_user = new TiXmlElement(tag::USER);
        xml_user << user;
        root->LinkEndChild(xml_user);
      }

      return xmlhelpers::dump(doc, data);
    }
  }
}
