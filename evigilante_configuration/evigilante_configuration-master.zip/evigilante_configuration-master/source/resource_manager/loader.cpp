#include "loader.hpp"

namespace eos
{
  namespace eosconfig
  {
  }
}
