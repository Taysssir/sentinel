#include "catch.hpp"
#include "eos/configuration/configuration.hpp"
#include "resource_manager/file.hpp"

TEST_CASE("users : create, open functions", "[users]")
{
  eos::Configuration config;

  config.open("users.eos");

  eos::UsersSharedPointer users = config.users();
  REQUIRE(users);

  eos::User *user = users->add_users();
  user->set_login("jerome");
  user->set_password("password");
  user->set_type(eos::User::Administrator);
  //users->push_back(user);
  eos::User::Layout *layout = user->mutable_layout()->add_children();
  layout->set_type("test");
  layout->set_orientation(eos::User::Layout::Horizontal);
  // user.set_layout(layout);

  config.save();

  eos::file::copy("users.eos", "another_users.eos");
  eos::file::remove("users.eos");

  eos::Configuration config2;
  config2.open("another_users.eos");
  eos::UsersSharedPointer users2 = config2.users();
  REQUIRE(users->users().size());
  eos::User user2 = users->users().Get(0);
  REQUIRE(user2.login() == "jerome");
  REQUIRE(user2.password() == "password");
  REQUIRE(user2.type() == eos::User::Administrator);
  eos::User::Layout layout2 = user->layout().children().Get(0);
  REQUIRE(layout2.type() == "test");
  REQUIRE(layout2.orientation() == eos::User::Layout::Horizontal);
}
